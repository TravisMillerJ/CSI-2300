import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.util.ArrayList;

public class SimpleQuizApp {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            // Start the quiz app
            QuizGUI quizGUI = new QuizGUI();
            quizGUI.displayQuestion();
        });
    }
}

// GUI class for displaying the quiz
class QuizGUI {
    private JFrame frame;
    private JTextPane textPane;
    private JButton[] answerButtons;
    private int currentQuestionIndex;
    private int score;
    private List<Question> questions;  // List to hold questions

    public QuizGUI() {
        // Initialize the list of questions
        questions = new ArrayList<>();
        questions.add(new Question("Which of the following is a primitive data type in Java?",
                new String[]{"String", "int", "ArrayList", "Scanner"}, "int"));
        questions.add(new Question("Which keyword is used to define a class in Java?",
                new String[]{"method", "class", "define", "object"}, "class"));
        questions.add(new Question("What is the size of an int in Java?",
                new String[]{"2 bytes", "4 bytes", "8 bytes", "16 bytes"}, "4 bytes"));
        questions.add(new Question("Which method is used to start a thread in Java?",
                new String[]{"run()", "execute()", "start()", "begin()"}, "start()"));
        questions.add(new Question("Which of the following is not a collection in Java?",
                new String[]{"List", "Set", "Queue", "Object"}, "Object"));

        // Set up the GUI elements
        frame = new JFrame("Simple Quiz App");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(5, 1));

        textPane = new JTextPane();
        textPane.setEditable(false);
        textPane.setText("Loading...");  // Initial message
        textPane.setForeground(Color.YELLOW);
        textPane.setBackground(Color.BLACK);

        answerButtons = new JButton[4];
        for (int i = 0; i < 4; i++) {
            answerButtons[i] = new JButton("Answer " + (i + 1));  // Placeholder text
            final int index = i;
            answerButtons[i].addActionListener(e -> checkAnswer(index));  // Event handler for clicks
            panel.add(answerButtons[i]);
        }

        frame.getContentPane().add(BorderLayout.CENTER, textPane);
        frame.getContentPane().add(BorderLayout.SOUTH, panel);
        frame.setVisible(true);
    }

    // Start displaying the questions
    public void displayQuestion() {
        currentQuestionIndex = 0;  // Start from the first question
        score = 0;  // Initialize score
        showNextQuestion();
    }

    // Method to show the next question
    private void showNextQuestion() {
        if (currentQuestionIndex < questions.size()) {
            Question currentQuestion = questions.get(currentQuestionIndex);
            String questionWithScore = "Score: " + score + "\n\n" + currentQuestion.getQuestion();
            textPane.setText(questionWithScore);

            String[] currentChoices = currentQuestion.getChoices();
            for (int i = 0; i < answerButtons.length; i++) {
                if (i < currentChoices.length) {
                    answerButtons[i].setText(currentChoices[i]);
                    answerButtons[i].setEnabled(true);  // Enable buttons
                } else {
                    answerButtons[i].setText("");  // Clear extra buttons
                    answerButtons[i].setEnabled(false);  // Disable extra buttons
                }
            }
        } else {
            // When the quiz is finished
            textPane.setText("Quiz completed! Final score: " + score);
            for (JButton button : answerButtons) {
                button.setEnabled(false);  // Disable buttons after the quiz ends
            }
        }
    }

    // Method to check the answer
    private void checkAnswer(int selectedIndex) {
        Question currentQuestion = questions.get(currentQuestionIndex);
        String selectedAnswer = answerButtons[selectedIndex].getText();
        String correctAnswer = currentQuestion.getCorrectAnswer();

        if (selectedAnswer.equals(correctAnswer)) {
            score++;  // Increase score if the answer is correct
        }

        currentQuestionIndex++;  // Move to the next question
        showNextQuestion();  // Show the next question
    }
}

// Question class for storing question details
class Question {
    private String question;
    private String[] choices;
    private String correctAnswer;

    // Constructor for the Question class
    public Question(String question, String[] choices, String correctAnswer) {
        this.question = question;
        this.choices = choices;
        this.correctAnswer = correctAnswer;
    }

    // Getter methods for the question, choices, and correct answer
    public String getQuestion() {
        return question;
    }

    public String[] getChoices() {
        return choices;
    }

    public String getCorrectAnswer() {
        return correctAnswer;
    }
}
